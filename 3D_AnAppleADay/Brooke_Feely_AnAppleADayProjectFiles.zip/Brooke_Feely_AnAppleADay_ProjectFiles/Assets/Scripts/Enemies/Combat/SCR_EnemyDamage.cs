using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class SCR_EnemyDamage : MonoBehaviour
{
    [Header("Player Components")]
    public Component playerCollider;
    public GameObject thrownApple;

    public bool isHit;

    void Start()
    {
        isHit = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision collision)
    {
        isHit = true;
    }
}
