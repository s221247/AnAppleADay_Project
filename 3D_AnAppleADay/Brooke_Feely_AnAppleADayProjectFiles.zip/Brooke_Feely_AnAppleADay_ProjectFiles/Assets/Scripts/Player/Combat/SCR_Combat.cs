using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SCR_Combat : MonoBehaviour
{
    //Refs to add in inspector - Combat section
    [Header("References")]
    public Transform throwPoint;
    public Transform throwDirection;
    public GameObject appleObject;

    //Adjust settings in inspector
    [Header("Settings")]
    public int maxCapacity;
    public float throwCooldown;

    //Input and 
    [Header("Throw")]
    public KeyCode throwApple = KeyCode.Space;
    public float throwForce;
    public float throwUpwardForce;
    bool canThrow;

    //Refs to add in inspector - Healing
    [Header("Healing")]
    public Slider healthBar;
    public KeyCode healSelf = KeyCode.LeftShift;
    public int healIncrement;
    bool canHeal;

    void Start()
    {
        canThrow = true;
    }

    //When throw pressed, bool is true and capacity above 0 is fulfilled, throw apple
    void Update()
    {
        if (Input.GetKeyDown(throwApple) && canThrow && maxCapacity > 0)
        {
            Throw();
        }

        if (Input.GetKeyDown(healSelf) && canHeal && maxCapacity > 0)
        {

        }
    }

    void Throw()
    {   
        //Prevent double throwing
        canThrow = false;

        //Create clone of prefab and place into position in space
        //+ collect rigidbody component to apply physics
        GameObject apple = Instantiate(appleObject, throwPoint.position, throwDirection.rotation);
        Rigidbody appleRb = apple.GetComponent<Rigidbody>();

        //Add force to move but only once (impulse) - continuous force no bueno here
        Vector3 forceToAdd = (throwDirection.transform.forward * throwForce) + (transform.up * throwUpwardForce);
        appleRb.AddForce(forceToAdd, ForceMode.Impulse);

        //Remove ability per throw then begin cooldown (immediately through GameEvent invoke)
        //Destroy apple after 6 seconds (if doesn't hit enemy)
        maxCapacity--;
        Invoke(nameof(ResetThrow), throwCooldown);
    }

    void ResetThrow()
    {
        canThrow = true;
    }

    void Heal()
    {
        
        //healIncrement += healthBar;
    }
}
