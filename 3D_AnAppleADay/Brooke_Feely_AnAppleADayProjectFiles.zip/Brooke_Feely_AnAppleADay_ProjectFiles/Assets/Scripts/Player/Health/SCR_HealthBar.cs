using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SCR_HealthBar : MonoBehaviour
{
    //Reference slider Inspector component 
    public Slider slider;

    //Placed first to start at max value
     public void SetMaxHealth(int health)
    {
       slider.maxValue = 100;
       slider.value = health;
    }

    //Have I conflicted things by telling it health and death may be same thing? WELP
    //Connect health value to slider component setting
    public void SetHealth(int health)
    {
       slider.value = health;
               if(health <= 0)
       {
            health = 0;
       }
    }
}
