using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SCR_PlayerHealth : MonoBehaviour
{
    //Refs for player health values
    public int maxHealth = 100;
    public int currentHealth;
    public SCR_HealthBar healthBar;

    //Enemy object references - pop Doctor prefab into inspector
    public GameObject enemy;

    //Start game with full health & get enemy colliders
    void Awake()
    {
      currentHealth = maxHealth;
      healthBar.SetHealth(maxHealth);   

      enemy.GetComponent<Collider>();
    }

    void Start()
    {
        
    }

    // NEED TO MAKE ENEMY HURT
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.LeftShift))
        {
            if(currentHealth <= 0)
            {
                currentHealth = 0;
            }

            TakeDamage(10);
        }

        //If health reaches 0, activate Death Menu scene
        if (currentHealth == 0)
        {
            DeathScreen();
        }
    }

    //Decrease health when hit, update healthbar (Healthbar slider should adjust)
    public void TakeDamage(int damage)
    {
        currentHealth -= damage;

        healthBar.SetHealth(currentHealth);
    }

    //Load scene 2 (Death Screen)
    public void DeathScreen()
    {
        SceneManager.LoadSceneAsync(2);
    }

}