using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class SCR_GoldAppleInventory : MonoBehaviour
{
    public int numberRed {get; private set; }
    public int numberGold {get; private set; }
    public UnityEvent<SCR_GoldAppleInventory> OnAppleCollected;

    public void AppleCollected()
    {
        numberGold++;
        OnAppleCollected.Invoke(this);
    }
}
