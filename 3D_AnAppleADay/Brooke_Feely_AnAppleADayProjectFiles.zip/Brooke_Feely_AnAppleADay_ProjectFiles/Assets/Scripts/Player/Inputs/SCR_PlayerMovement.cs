using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SCR_PlayerMovement : MonoBehaviour
{

    // Movement - referencing Unity's controller component, speed adjustment and a variable for xyz values.
    [SerializeField] CharacterController controller;
    [SerializeField] float playerSpeed;
    Vector3 playerMovementInput;
    
    // 
    void Update()
    {
        MovePlayer();
    }

      //Get input from the x/z axis (no input for y), move the player and normalise (to prevent faster speed on diagonal)
      //Move direction then multiplied by speed and frame time.
      void MovePlayer()
    {
      playerMovementInput = new Vector3(Input.GetAxis("Horizontal"), 0f, Input.GetAxis("Vertical"));

      Vector3 moveDirection = transform.TransformDirection(playerMovementInput).normalized;
      controller.Move(moveDirection * playerSpeed * Time.deltaTime);
    } 
}
