using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class SCR_LightSwitch : MonoBehaviour
{
    [Header("Light Layers")]
    //Light objects for each layer of 'light radius' around player
    public GameObject light1;
    public GameObject light2;
    public GameObject light3;

     [Header("Exit Mode")]
    //Bools for when all lights are on and when all golden apples are used (destroyed)
    public bool allCollected; 

    [Header("Inventory Count")]
    public int requiredGold = 3;
    public static int currentGold = SCR_Inventory.numberGold;

    void Awake()
    {
        allCollected = false;
        light1.SetActive(false);
        light2.SetActive(false);
        light3.SetActive(false);
    }

    //Continually check for light setting validity
    void Update()
    {
        AdjustLightRadius();
    }

    public void AdjustLightRadius()
    {
        if(SCR_Inventory.numberGold == 1)
        {
            light1.SetActive(true);
            light2.SetActive(false);
            light3.SetActive(false);
        }
        
        else if(SCR_Inventory.numberGold == 2)
        {
            light1.SetActive(false);
            light2.SetActive(true);
            light3.SetActive(false);
        }
        
        else if(SCR_Inventory.numberGold == 3)
        {
            light1.SetActive(false);
            light2.SetActive(false);
            light3.SetActive(true);

            allCollected = true;
        }
        else /*if(currentGold == 0)*/
        {
            light1.SetActive(false);
            light2.SetActive(false);
            light3.SetActive(false);
        }
    } 
}
