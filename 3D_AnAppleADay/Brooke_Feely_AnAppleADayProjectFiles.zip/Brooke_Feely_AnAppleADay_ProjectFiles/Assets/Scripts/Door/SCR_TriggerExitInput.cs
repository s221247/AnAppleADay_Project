using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SCR_TriggerExitInput : MonoBehaviour
{
    
    bool isExitAvailable;
    // need to identify what isExitAvailable = (make it another script?)
    
    // Start is called before the first frame update
    void Awake()
    {

    }

    void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Player"))
        {
            //Does player hold all 3 apples?
            

            if (isExitAvailable == true)
            {
                //Must only happen if player holds all 3 gold apples
                Destroy(this, 3f);
            }
            
        }
    }
}
