using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SCR_Apple : MonoBehaviour
{
   //Referencing game objects in Unity (add in Inspector)
   //public GameObject redAppleObject;
   public GameObject goldAppleObject;
   public GameObject redAppleObject;

   //Set as booleans to differentiate functions
   public bool isGold;
   public bool isRed;

   //When an object with a collider holding the Inventory script enters this collision space,
   //Activate 'AppleCollected' function, which increases UI text apple count.
   //If red, destroy object. If gold, hide object.
   void OnTriggerEnter(Collider other)
   {
    SCR_Inventory inventory = other.GetComponent<SCR_Inventory>();

    if(inventory != null)
    {
      //May need to make a new function or adjust original to make sure only 1 text is affected
      //inventory.RedAppleCollected();
      //inventory.GoldAppleCollected();

      if(isRed == true)
      {
        inventory.RedAppleCollected();
        Destroy(redAppleObject);
        Debug.Log("Destroyed Red Apple");
      }

      if (isGold == true)
      {
        inventory.GoldAppleCollected();
        goldAppleObject.SetActive(false);
        Debug.Log("Hid Gold Apple");
      }
    }
   }
}
