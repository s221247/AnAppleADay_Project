using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using TMPro;

public class SCR_InventoryTwo : MonoBehaviour
{
    //Set to readable by other scripts, only settable by this one
    public static int numberRed {get; private set; }
    public static int numberGold {get; private set; }
    [SerializeField] TMP_Text panicMessage;

    //For exit door access
    public bool atExit = false;
    public bool canUseGolden = false;
    public int maximumGold = 3;
    [SerializeField] GameObject goldenAppleObject;

    //Unity Event System to call the functions within this script
    public UnityEvent<SCR_InventoryTwo> OnRedAppleCollected;
    public UnityEvent<SCR_InventoryTwo> OnGoldAppleCollected;
    public UnityEvent<SCR_InventoryTwo> OnUseGoldenApple;

    void Update()
    {
         if(SCR_InventoryTwo.numberGold == maximumGold)
        {
            ShowMessage();
        }
    }
    
    //When Golden Apple picked up, increase UI count and start script event
    public void GoldAppleCollected()
    {
        SCR_InventoryTwo.numberGold++;
        OnGoldAppleCollected.Invoke(this);
    }

    //When Red Apple picked up, increase UI count and start script event 
    public void RedAppleCollected()
    {
        SCR_InventoryTwo.numberRed++;
        OnRedAppleCollected.Invoke(this);
    }

    //When all gold apples collected, set exit message visible
    void ShowMessage()
    {
        panicMessage.gameObject.SetActive(true);
    }

       void OnTriggerEnter(Collider other)
   {
        if(other.CompareTag("ExitCollider") && SCR_InventoryTwo.numberGold == 3)
        {
            canUseGolden = true;

             if(canUseGolden = true && Input.GetKeyDown(KeyCode.E))
            {
                numberGold--;
                Destroy(goldenAppleObject);
            }

        OnUseGoldenApple.Invoke(this);
        }
   }
}
