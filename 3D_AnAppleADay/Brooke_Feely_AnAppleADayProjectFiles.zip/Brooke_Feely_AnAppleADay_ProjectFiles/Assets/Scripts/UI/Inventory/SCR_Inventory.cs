using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using TMPro;

public class SCR_Inventory : MonoBehaviour
{
    //Set to readable by other scripts, only settable by this one
    public static int numberRed {get; private set; }
    public static int numberGold {get; private set; }
    [SerializeField] TMP_Text panicMessage;
    public static int maximumGold = 3;
    public static int maximumRed = 4;


    //Unity Event System to call these functions
    public UnityEvent<SCR_Inventory> OnRedAppleCollected;
    public UnityEvent<SCR_Inventory> OnGoldAppleCollected;

    void Update()
    {
        if (SCR_Inventory.numberGold == maximumGold)
        {
            ShowMessage();
        }
    }

    public void GoldAppleCollected()
    {
        numberGold++;
        OnGoldAppleCollected.Invoke(this);
    }

    public void RedAppleCollected()
    {
        numberRed++;
        OnRedAppleCollected.Invoke(this);
    }

    //When all gold apples collected, set exit message visible
    void ShowMessage()
    {
        panicMessage.gameObject.SetActive(true);
    }
}
