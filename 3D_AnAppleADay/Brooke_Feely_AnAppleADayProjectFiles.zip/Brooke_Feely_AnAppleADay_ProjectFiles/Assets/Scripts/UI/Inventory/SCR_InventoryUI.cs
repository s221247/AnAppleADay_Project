using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class SCR_InventoryUI : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI redText;
    [SerializeField] TextMeshProUGUI goldText;

    //Get Apple count text at game start
    void Start()
    {
        redText = GetComponent<TextMeshProUGUI>();
        goldText = GetComponent<TextMeshProUGUI>();
    }

    //When inventory count (numbers from Inventory script) adjusted, update UI text
    public void UpdateRedText(SCR_Inventory inventory)
    {
        redText.text = SCR_Inventory.numberRed.ToString();
    }

    public void UpdateGoldText(SCR_Inventory inventory)
    {
        goldText.text = SCR_Inventory.numberGold.ToString();
    }
}
