using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SCR_MainMenu : MonoBehaviour
{
    //Load scene 1 from build list (Core Game)
    public void StartGame()
    {
        SceneManager.LoadSceneAsync(1);
    }

    //Close application
    public void ExitGame()
    {
        Application.Quit();
    }

    //Load scene 0 from build list (Main Menu)
    public void ReturnToMenu()
    {
        SceneManager.LoadSceneAsync(0);
    }

}
