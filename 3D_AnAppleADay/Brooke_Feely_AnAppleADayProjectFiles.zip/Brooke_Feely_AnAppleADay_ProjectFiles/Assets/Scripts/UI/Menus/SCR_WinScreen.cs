using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SCR_WinScreen : MonoBehaviour
{


    public void WinScreen(bool escape)
    {
        if (escape == true)
        {
            SceneManager.LoadSceneAsync(3);
        }

    }
}
