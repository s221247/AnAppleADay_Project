using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SCR_PauseMenu : MonoBehaviour
{
    //Add Pause menu object into inspector + boolean for starting Pause Menu state
    [SerializeField] GameObject pauseMenu;
    bool pauseActive;

    //Ensure time is normal on start (running at 1x speed)
    void Start()
    {
        Time.timeScale = 1f;
    }

    //During play, if Esc is pressed enable/disable Pause Menu according to bool value
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (pauseActive == true)
                DisablePause();

            else
            {
               EnablePause();
            }
        }
    }

    //Open Main Menu scene
    public void ReturnToMenu()
    {
        SceneManager.LoadSceneAsync(0);
    }

    //Unpause game - resume 1x time, disable menu
    public void DisablePause()
    {
        pauseMenu.SetActive(false); 
        Time.timeScale = 1f;

        pauseActive = false;
    }

    //Pause game - set time to 0 (no frames, no movement), enable menu
    public void EnablePause()
    {
        pauseMenu.SetActive(true);
        Time.timeScale = 0f;
        pauseActive = true;
    }

    //Return last active game scene 
    public void RestartGame()
    {
        SceneManager.LoadSceneAsync(1);
        //SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
}
