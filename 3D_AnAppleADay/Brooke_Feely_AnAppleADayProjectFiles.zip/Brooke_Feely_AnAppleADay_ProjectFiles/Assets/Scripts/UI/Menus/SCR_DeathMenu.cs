using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SCR_DeathMenu : MonoBehaviour
{
    //Grab script from Healthbar
    SCR_HealthBar sCR_HealthBar;

    //If player health is 0, load death screen.
    public void DeathScreen(int death)
    {   
        if (death == 0)
        {
            SceneManager.LoadSceneAsync(2);
        }

    }
}
